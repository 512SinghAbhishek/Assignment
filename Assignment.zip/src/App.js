import logo from './logo.svg';
import './App.css';
import Test from './Component/Test';

function App() {
  return (
    <div className="App">
      <Test />
    </div>
  );
}

export default App;
